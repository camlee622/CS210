/*

Cameron Lee
03/13/2022
CS-250 Project One
Clocks Code

*/
#define _CRT_SECURE_NO_WARNINGS
// Including all the files needed
#include <iostream>
#include <ctime>
#include <string>
#include <iomanip>
#include <time.h>

using namespace std;

// Declaring all variables for the program
int hoursStandard; // 12-Hour
int hoursMilitary; // 24-Hour
int minutes; // Minutes
int seconds; // Seconds
string meridiem; // AM or PM


// ---------------------------------------- FUNCTIONS ----------------------------------------
// Function to add hours to the clock
void addHour() {
	hoursStandard = hoursStandard + 1; // Increment hours

	// Conversion between Standard and Military Time and AM to PM
	if (hoursStandard >= 12) {				
		hoursStandard = hoursStandard - 12;
		if (meridiem == "AM")
			meridiem = "PM";
		else
			meridiem = "AM";
	}
}

// Function to add minutes to the clock
void addMinute() {
	minutes += 1; // Increment minutes
	
	// Add an hour if the minutes goes over 60
	if (minutes >= 60) {
		minutes = 0; // Reset minutes
		addHour();
	}
}

// Function to add seconds to the clock
void addSecond() {
	seconds += 1; // Increment seconds
	
	// Add a minute if the seconds goes over 60
	if (seconds >= 60) {
		seconds = 0; // Reset seconds
		addMinute();
	}
}

// Function to display the menu to the user
void displayMenu() {
	cout << endl << endl << endl; // Three endlines to give spacing
	cout << " ********************************\n";
	cout << " * 1 - Add One Hour             *\n";
	cout << " * 2 - Add One Minute           *\n";
	cout << " * 3 - Add One Second           *\n";
	cout << " * 4 - Exit Program             *\n";
	cout << " ********************************";
	cout << endl << endl << endl; // Three endlines to give spacing
	
	cout << "Pick a menu option: ";
}

// Function to display both clocks
void displayClocks() {

	
	// MENU - TOP LINE
	cout << " " << setfill('*') << setw(23) << "" << "\t\t";
	cout << setfill('*') << setw(23) << "" << endl;
	// MENU - TEXT LINE
	cout << " *    12-Hour Clock    *" << "\t\t" << "*    24-Hour Clock    *" << endl;
	// MENU - TIME LINE
	printf(" *     %02d:%02d:%02d", hoursStandard, minutes, seconds);
	cout << " " << meridiem << "     *";
	printf("\t\t*      %02d:%02d:%02d       *", hoursMilitary, minutes, seconds);
	cout << endl;
	// MENU - BOTTOM LINE
	cout << " " << setfill('*') << setw(23) << "" << "\t\t";
	cout << setfill('*') << setw(23) << "" << endl;
}

void clockConversion() {
	if (meridiem == "AM") {
		hoursMilitary = hoursStandard;
		if (hoursMilitary >= 24) {
			hoursMilitary = hoursMilitary - 24;
		}
	}
	else {
		hoursMilitary = hoursStandard + 12;
	}
}

// ---------------------------------------- MAIN ----------------------------------------

int main() {
	
	// Setting initial variables 
	int userChoice = 0;

	//	---------------------------------------- System Time Block  ---------------------------------------- 
	time_t total_seconds = time(0);
	struct tm* ct = localtime(&total_seconds);
	seconds = ct->tm_sec;
	minutes = ct->tm_min;
	hoursStandard = ct->tm_hour;

	// Obtain current meridiem using current military time
	if (hoursMilitary >= 12) {
		meridiem = "PM";
	}
	else {
		meridiem = "AM";
	}
	// ---------------------------------------- End of System Time Block ---------------------------------------- 

	
	// Setting up while(1) loop to initialize immediately and start the program
	while (1) {



		// Calling function to calculate difference between standard and military clock
		clockConversion();

		// Calling function to display clocks
		displayClocks();

		// Calling function to display menu
		displayMenu();

		// Getting user input for the menu options
		cin >> userChoice;

		// Option 1 of menu - Add One hour
		if (userChoice == 1) {
			addHour();
		}
		// Option 2 of menu - Add one minute
		else if (userChoice == 2) {
			addMinute();
		}
		// Option 3 of menu - Add one second
		else if (userChoice == 3) {
			addSecond();
		}
		// Option 4 of menu - Exit program
		else if (userChoice == 4) {
			cout << "Thank you, goodbye!\n\n\n";
			break;
		}
		// Error message if user doesn't enter option 1-4
		else {
			cout << "Invalid option. Please select an option from the menu provided.";
		}
	}
}